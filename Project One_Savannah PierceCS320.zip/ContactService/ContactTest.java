import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



public class ContactTest {



    @Test

    public void testValidContact() {

        Contact contact = new Contact("12345", "Savannah", "Pierce", "1234567890", "123 Main Street");



        assertEquals("12345", contact.getContactId());

        assertEquals("Savannah", contact.getFirstName());

        assertEquals("Pierce", contact.getLastName());

        assertEquals("1234567890", contact.getPhone());

        assertEquals("123 Main Street", contact.getAddress());

    }



    @Test

    public void testContactIdCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact(null, "Savannah", "Pierce", "1234567890", "123 Main Street");

        });

    }



    @Test

    public void testContactIdCannotBeTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345678901", "Savannah", "Pierce", "1234567890", "123 Main Street");

        });

    }



    @Test

    public void testFirstNameCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", null, "Pierce", "1234567890", "123 Main Street");

        });

    }



    @Test

    public void testFirstNameCannotBeTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "LongerThan10", "Pierce", "1234567890", "123 Main Street");

        });

    }



    @Test

    public void testLastNameCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "Savannah", null, "1234567890", "123 Main Street");

        });

    }



    @Test

    public void testLastNameCannotBeTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "Savannah", "LongerThan10", "1234567890", "123 Main Street");

        });

    }



    @Test

    public void testPhoneCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "Savannah", "Pierce", null, "123 Main Street");

        });

    }



    @Test

    public void testPhoneMustBeExactly10Digits() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "Savannah", "Pierce", "12345", "123 Main Street");

        });

    }



    @Test

    public void testAddressCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "Savannah", "Pierce", "1234567890", null);

        });

    }



    @Test

    public void testAddressCannotBeTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {

            new Contact("12345", "Savannah", "Pierce", "1234567890",

                    "This address is definitely over thirty characters");

        });

    }



    @Test

    public void testUpdateFields() {

        Contact contact = new Contact("12345", "Savannah", "Pierce", "1234567890", "123 Main Street");



        contact.setFirstName("Anna");

        contact.setLastName("Smith");

        contact.setPhone("0987654321");

        contact.setAddress("456 Oak Road");



        assertEquals("Anna", contact.getFirstName());

        assertEquals("Smith", contact.getLastName());

        assertEquals("0987654321", contact.getPhone());

        assertEquals("456 Oak Road", contact.getAddress());

    }

}
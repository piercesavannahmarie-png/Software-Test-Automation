import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("A123", futureDate, "Doctor appointment");

        assertEquals("A123", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentIdCannotExceedTenCharacters() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", null, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentDateCannotBeInThePast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", pastDate, "Doctor appointment");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", futureDate, null);
        });
    }

    @Test
    public void testDescriptionCannotExceedFiftyCharacters() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", futureDate,
                    "This description is definitely longer than fifty characters total.");
        });
    }
}

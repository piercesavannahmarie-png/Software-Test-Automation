import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment(
                "A123",
                new Date(System.currentTimeMillis() + 86400000),
                "Doctor appointment");

        service.addAppointment(appointment);

        assertNotNull(service.getAppointment("A123"));
        assertEquals("A123", service.getAppointment("A123").getAppointmentId());
    }

    @Test
    public void testCannotAddDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();
        Appointment appointment1 = new Appointment(
                "A123",
                new Date(System.currentTimeMillis() + 86400000),
                "Doctor appointment");
        Appointment appointment2 = new Appointment(
                "A123",
                new Date(System.currentTimeMillis() + 172800000),
                "Dental appointment");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment(
                "A123",
                new Date(System.currentTimeMillis() + 86400000),
                "Doctor appointment");

        service.addAppointment(appointment);
        service.deleteAppointment("A123");

        assertNull(service.getAppointment("A123"));
    }

    @Test
    public void testDeleteNonexistentAppointmentThrowsException() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("BADID");
        });
    }
}

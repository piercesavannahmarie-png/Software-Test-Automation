import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("T123", "Homework", "Complete Java milestone");
        assertEquals("T123", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete Java milestone", task.getDescription());
    }

    @Test
    public void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete Java milestone");
        });
    }

    @Test
    public void testTaskIdCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete Java milestone");
        });
    }

    @Test
    public void testTaskNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", null, "Complete Java milestone");
        });
    }

    @Test
    public void testTaskNameCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", "ThisTaskNameIsWayTooLong", "Complete Java milestone");
        });
    }

    @Test
    public void testTaskDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T123", "Homework", null);
        });
    }

    @Test
    public void testTaskDescriptionCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                "T123",
                "Homework",
                "This description is definitely longer than fifty characters and should fail."
            );
        });
    }
}
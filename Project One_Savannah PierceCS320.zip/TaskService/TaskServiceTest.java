import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("T001", "Task One", "First task description");

        service.addTask(task);

        assertEquals(task, service.getTask("T001"));
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("T001", "Task One", "First task description");

        service.addTask(task);
        service.deleteTask("T001");

        assertNull(service.getTask("T001"));
    }

    @Test
    public void testAddDuplicateTaskFails() {
        TaskService service = new TaskService();

        Task task1 = new Task("T001", "Task One", "First task description");
        Task task2 = new Task("T001", "Task Two", "Second task description");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testUpdateTaskName() {
        TaskService service = new TaskService();

        Task task = new Task("T001", "Task One", "First task description");

        service.addTask(task);

        service.updateName("T001", "Updated Task");

        assertEquals("Updated Task",
            service.getTask("T001").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        TaskService service = new TaskService();

        Task task = new Task("T001", "Task One", "First task description");

        service.addTask(task);

        service.updateDescription("T001", "Updated description");

        assertEquals("Updated description",
            service.getTask("T001").getDescription());
    }
}